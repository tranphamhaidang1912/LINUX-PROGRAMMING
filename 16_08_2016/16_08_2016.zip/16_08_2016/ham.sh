#!/bin/sh

foo()
{
	echo "Function foo is executing"
}
echo "script is starting"
foo
echo "script ended"
exit 0