#!/bin/sh

for user in a01 mpi grid
do
	echo $user
done
exit 0