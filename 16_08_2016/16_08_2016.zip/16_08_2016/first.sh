echo "Day la chuong trinh dau tien cua toi"
