#!/bin/sh

if [ $1 = "/home/a01" ] 
	then
	echo "Hello a01"
else
	echo "Guest"
fi
exit 0