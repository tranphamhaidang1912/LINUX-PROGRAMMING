#include <stdio.h>

void main()
{
	printf("Ket qua dung ham nhapTen:\n");
	nhapTen();
	printf("Ket qua dung ham nhapNgaySinh:\n");
        nhapNgaySinh();

}
