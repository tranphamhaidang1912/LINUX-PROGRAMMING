int main()
{
	printf("%d",ham1());
	exit(0);
}
