#include <stdio.h>

void nhapTen()
{
	char ten[100];
	printf("Nhap ten:");
	gets(ten);
	printf("Xin chao ");
	puts(ten);
}
