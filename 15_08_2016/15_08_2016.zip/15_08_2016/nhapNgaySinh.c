#include <stdio.h>

void nhapNgaySinh()
{
	char ngaySinh[100];
	printf("Nhap ngay sinh:");
	gets(ngaySinh);
	printf("Ngay sinh cua ban: ");
	puts(ngaySinh);
}
