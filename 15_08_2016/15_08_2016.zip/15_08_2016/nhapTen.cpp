#include <iostream>
#include <string>
using namespace std;

int main()
{
	string ten;
	cout<<"Nhap ten: ";
	getline(cin,ten);
	cout<<ten<<endl;
}
