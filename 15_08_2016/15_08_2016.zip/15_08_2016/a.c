int ham1()
{
return 1;
}
