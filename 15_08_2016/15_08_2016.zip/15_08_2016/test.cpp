#include <iostream>
using namepace std;

int main()
{
	cout<<"Ket qua dung ham nhapTen: %d\n", nhapTen();
	cout<<"Ket qua dung ham nhapNgaySinh: %d\n", nhapNgaySinh();

}
