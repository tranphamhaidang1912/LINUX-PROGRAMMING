#include <iostream>
#include <string>
using namespace std;

int main()
{
	string ngaySinh;
	cout<<"Nhap ngay sinh: ";
	getline(cin,ngaySinh);
	cout<<ngaySinh<<endl;
}
