

int main()
{
	printf("Ket qua dung ham func1: %d\n", func1());
	exit(0);
}
